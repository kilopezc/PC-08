﻿namespace PRIMERPARCIAL
{
    class Program
    {
        static void Main(string []aArgs)
        {
            //Variables
            double num1, num2,num3;
            //Entrada
            Console.WriteLine("Ingrese el numero 1");
            num1=Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Ingrese el numero 2");
            num2=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese el numero 3");
            num3=Convert.ToInt32(Console.ReadLine());

            //Proceso
            if(num1>num2 && num1>num3 && num2>num3)
            {
                Console.WriteLine("Numero mayor es: "+num1);
                Console.WriteLine("Numero menor es: "+num3);
            }
            else if(num2>num1 && num2>num3 && num3>num1)
            {
                Console.WriteLine("Numero mayor es: "+num2);
                Console.WriteLine("Numero menor es: "+num1);
            }
            else{
                Console.WriteLine("Numero mayor es: "+num3);
                Console.WriteLine("Numero menor es: "+num1);
            }
        }
    }
}