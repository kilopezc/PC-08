﻿using System.Reflection.Metadata.Ecma335;
using System.Runtime.CompilerServices;

namespace PRUEBA_CORTA
{
    public class Estudiante 
    {
        string nombre;
        int edad;
        string carrera;
        string carnet;
        int notaAdmision;
        bool matricularse;
        //Se puede matricular o no
        Estudiante(string nombre, int edad, string carrera,string carnet,int notaAdmision) 
        {
            this.nombre = nombre;
            this.edad = edad;
            this.carrera = carrera;
            this.carnet = carnet;
            this.notaAdmision = notaAdmision;
        }
        //Método que muestra los datos del estudiante
        void MostrarResumen() 
        {
            Console.WriteLine("Nombre:");
            Console.WriteLine(this.nombre);
            Console.WriteLine("Edad:");
            Console.WriteLine(this.edad);
            Console.WriteLine("Carrera:");
            Console.WriteLine(this.carrera);
            Console.WriteLine("Carnet:");
            Console.WriteLine(this.carnet);
            Console.WriteLine("Nota de admision:");
            Console.WriteLine(this.notaAdmision);
        }
        public bool Matricularse()
        {
            if ((notaAdmision>=75 && notaAdmision<=100) && carnet.EndsWith("2025"))
            {
                matricularse=true;
                return matricularse;
            }
            else{
                matricularse=false;
                return matricularse;
            }
        }
    
        public static void Main()
        {
            Console.Write("Ingrese su nombre: ");
            string nombre = Console.ReadLine();
            Console.Write("Ingrese su edad: ");
            int edad = Convert.ToInt32(Console.ReadLine());
            Console.Write("Ingrese su carrera: ");
            string carrera = Console.ReadLine();
            Console.Write("Ingrese su carnet: ");
            string carnet = Console.ReadLine();
            Console.Write("Ingrese su nota de admision: ");
            int notaAdmision = Convert.ToInt32(Console.ReadLine());

            Estudiante estudiante = new Estudiante(nombre,edad,carrera,carnet,notaAdmision);

            estudiante.MostrarResumen();
            
            if (estudiante.Matricularse())
            {
                Console.WriteLine("Puede Matricularse");
            }
            else
            {
                Console.WriteLine("No puede Matricularse");
            }
        }
    }
}

