﻿using System;
using Semana18;

namespace Principal
{
    class Principal
    {
        static void Main()
        {
            //Crear un objeto para Inicio, que es donde empieza el programa para solicitar los datos
            Inicio obj=new Inicio();
            obj.SolicitarDatos();
            //Obtener el arreglo de nombres ingresados 
            string[]nombre=obj.LeerNombres();
            //Obtener la matriz de notas ingresadas
            int[,]nota=obj.LeerNotas();
            //Crear un objeto para Menu 
            Menu menu = new Menu(nombre,nota); 
            menu.MostrarMenu();
        }
    }
}