using System;

namespace Semana18;

public class Inicio
{
    //Atributos
    string [] nombre=new string[10];
    int [,] nota=new int[10,10];
    //Metodo para solicitar los datos
    public void SolicitarDatos()
    {   
        //Variable que almacenará las notas que ingrese el usuario
        int notas;
        Console.WriteLine("Kenneth López - 1138025");
        Console.WriteLine("Ingrese 10 nombres junto con 10 notas para cada nombre");
        //Se repitirá el ciclo 10 veces, que es la cantidad de nombres
        for(int i=0;i<10;i++)
        {
            //While true por si se ingresan datos invalidos 
            while(true)
            {
                //Se solicita los nombres
                Console.WriteLine($"Ingrese el nombre {i}");
                string entradaNombres=Console.ReadLine();
                //Se verifica que no es un entero
                if(int.TryParse(entradaNombres, out _))
                {
                    Console.WriteLine("Error, ingrese un nombre correcto");
                }
                //Si no lo es se almacena en el arreglo nombre
                else
                {
                    nombre[i]=entradaNombres;
                    break;
                }
            }
            //Se repitirá 10 veces el ciclo que es la cantidad de notas ha ingresar
            for(int j=0;j<10;j++)
            {         
                //While true por si se ingresan datos invalidos 
                while(true)
                {
                    //Se solicita las notas
                    Console.WriteLine($"Ingrese la nota {j}");
                    string entradaNotas=Console.ReadLine();
                    //Se verifica que no es cadena 
                    if(int.TryParse(entradaNotas, out notas))
                    {
                        //Si no lo es se verifica que este dentr de un rango entre 0 y 100
                        if(notas>=0 && notas<=100)
                        {       
                            //Se almcena en la matriz nota             
                            nota[i,j]=notas;
                            break;
                        }
                        //Muestra mensaje de error si está fuera del rango
                        else
                        {
                            Console.WriteLine("Ingrese una nota dentro del rango de (0-100)");
                        }
                    }
                    //Muestra mensaje de error si se ingresa un caracter
                    else
                    {
                        Console.WriteLine("Error, ingrese una nota correcta");
                    }
                }
            }
        }
    }
    //Devuelve el arreglo de los nombres ingresados por el usuario
    public string[] LeerNombres()
    {
        return nombre;
    }
    //Devuelve la matriz de las notas ingresadas por el usuario 
    public int[,] LeerNotas()
    {
        return nota;
    }
}
