using System;

namespace Semana18;

public class Menu
{
    //Atributos
    private string[] nombre;
    private int[,] nota;
    //Constructor 
    public Menu(string[]nombres, int[,]notas)
    {
        nombre=nombres;
        nota=notas;
    }
    //Metodo para mostrar menu
    public void MostrarMenu()
    {
        //El ciclo se repitirá hasta que se desee salir 
        while(true)
        {
            //Se muestra el menu y se almacena la entrada
            Console.WriteLine("Bienvenido seleccione una opción\n1) Mostrar nombre y notas aprobadas para cada alumno.\n2) Mostrar nombre y notas no aprobadas para cada alumno.\n3) Mostrar el promedio de notas del grupo.\n4) Salir del programa");
            string opcion=Console.ReadLine();
            //Segun la opcion ingresada se verifican en los casos
            switch(opcion)
            {
                case "1":
                    MostrarNotas(true);
                break;
                case "2":
                    MostrarNotas(false);
                break;
                case "3":
                    MostrarPromedio();
                break;
                case "4":
                    return;
                default:
                    Console.WriteLine("Ingrese una opción válida");
                break;
            }
        }
    }
    //Metodo para mostrar notas
    public void MostrarNotas(bool notasAprovadas)
    {
        //El ciclo recorre la cantidad de estudiantes y muestra sus nombre
        for(int i=0;i<nombre.Length;i++)
        {
            Console.WriteLine($"Estudiante: {nombre[i]}");
            //Recorre las notas
            for(int j=0;j<10;j++)
            {
                //En una variable almacena las notas que se esten almacenando durante el ciclo 
                int notaActual=nota[i,j];
                //Si es true (notas aprovadas)
                if(notasAprovadas)
                {
                    //Muestra las notas arriba de 65
                    if(notaActual>=65)
                    {
                        Console.WriteLine($"Nota: {notaActual}");
                    }
                }
                //Si es false (notas no aprovadas)
                else
                {
                    //Muestra las notas arriba de 0 y abajo de 65
                    if(notaActual>0 && notaActual<65)
                    {
                        Console.WriteLine($"Nota: {notaActual}");
                    }
                }
            }
        }
    }
    //Metodo para calcular el promedio del grupo
    private void MostrarPromedio()
    {
        int sumaTotal=0; //Suma las notas
        int suma=0; //Suma la cantidad de notas
        double promedio; 
        for(int i=0;i<10;i++)
        {
            for(int j=0;j<10;j++)
            {
                sumaTotal+=nota[i,j]; //A la variable sumaTota se le hirá sumando las notas que pasen por el ciclo 
                suma++; //Se incrementará la cantidad de notas
            }
        }
        //Se calcula el promedio diviendo la suma de todas las notas sobre la cantidad de notas
        promedio=sumaTotal/suma;
        Console.WriteLine($"El promedio del grupo es: {promedio}");
    }
}
