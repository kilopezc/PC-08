﻿using System;
using System.Runtime.ExceptionServices;

class Arreglos
{
    static void Main()
    {
        int numero;
        int[] numeros = new int[9];
        //Solicitar el ingreso de 8 numeros
        for(int i=1;i<9;i++)
        {
            Console.WriteLine("Ingrese el numero "+i);
            numero=Convert.ToInt32(Console.ReadLine());
            //Guardar en un arreglo 
            numeros[i]=numero;
        }
        Console.ReadLine();
        Console.ReadKey();
        //Mostrar los 8 numeros ingresados 
        for (int i=1; i<9; i++)
        {
            Console.WriteLine($"Numero {i}: {numeros[i]}"); 
        }
        Console.ReadLine();
        Console.ReadKey();
        //Suma de los 8 numeros 
        int suma=numeros.Sum();
        Console.WriteLine($"La suma es: {suma}");
        Console.ReadLine();
        Console.ReadKey();
        //Promedio de los 8 numeros 
        double promedio;
        promedio=suma/numeros.Length;
        Console.WriteLine($"El promedio es: {promedio}");
    }
}
